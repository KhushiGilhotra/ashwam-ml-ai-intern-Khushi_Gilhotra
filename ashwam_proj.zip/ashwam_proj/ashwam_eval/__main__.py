import argparse
from .cli import run

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--data", required=True)
    parser.add_argument("--out", required=True)

    args = parser.parse_args()
    run(args.data, args.out)
