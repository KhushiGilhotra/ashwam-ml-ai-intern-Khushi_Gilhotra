from collections import defaultdict

def evidence_overlap(span_a, span_b):
    """
    Returns True if one evidence span overlaps the other.
    Simple substring-based overlap.
    """
    a = span_a.lower()
    b = span_b.lower()
    return a in b or b in a


def match_items(pred_items, gold_items):
    """
    Match predicted items to gold items using:
    - same domain
    - overlapping evidence span
    """
    matches = []
    used_gold = set()

    for p_idx, pred in enumerate(pred_items):
        for g_idx, gold in enumerate(gold_items):
            if g_idx in used_gold:
                continue

            if pred["domain"] != gold["domain"]:
                continue

            if evidence_overlap(pred["evidence_span"], gold["evidence_span"]):
                matches.append((p_idx, g_idx))
                used_gold.add(g_idx)
                break

    return matches


def score_journal(pred_items, gold_items):
    matches = match_items(pred_items, gold_items)

    tp = len(matches)
    fp = len(pred_items) - tp
    fn = len(gold_items) - tp

    polarity_correct = 0
    bucket_correct = 0

    for p_idx, g_idx in matches:
        pred = pred_items[p_idx]
        gold = gold_items[g_idx]

        if pred["polarity"] == gold["polarity"]:
            polarity_correct += 1

        bucket_key = (
            "arousal_bucket" if pred["domain"] == "emotion" else "intensity_bucket"
        )
        if pred.get(bucket_key) == gold.get(bucket_key):
            bucket_correct += 1

    return {
        "tp": tp,
        "fp": fp,
        "fn": fn,
        "polarity_correct": polarity_correct,
        "bucket_correct": bucket_correct,
        "total_gold": len(gold_items),
        "total_pred": len(pred_items),
    }
