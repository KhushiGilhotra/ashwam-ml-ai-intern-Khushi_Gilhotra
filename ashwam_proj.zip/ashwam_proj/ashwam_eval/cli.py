import os
from .utils import read_jsonl, write_json, write_jsonl
from .scorer import score_journal


def run(data_dir, out_dir):
    journals = read_jsonl(os.path.join(data_dir, "journals.jsonl"))
    gold = read_jsonl(os.path.join(data_dir, "gold.jsonl"))
    preds = read_jsonl(os.path.join(data_dir, "sample_predictions.jsonl"))

    gold_by_id = {g["journal_id"]: g["items"] for g in gold}
    preds_by_id = {p["journal_id"]: p["items"] for p in preds}

    os.makedirs(out_dir, exist_ok=True)

    summary = {
        "tp": 0,
        "fp": 0,
        "fn": 0,
        "polarity_correct": 0,
        "bucket_correct": 0,
        "total_gold": 0,
        "total_pred": 0,
    }

    per_journal = []

    for journal in journals:
        jid = journal["journal_id"]
        gold_items = gold_by_id.get(jid, [])
        pred_items = preds_by_id.get(jid, [])

        scores = score_journal(pred_items, gold_items)

        for k in summary:
            summary[k] += scores[k]

        per_journal.append({
            "journal_id": jid,
            **scores
        })

    write_json(os.path.join(out_dir, "score_summary.json"), summary)
    write_jsonl(os.path.join(out_dir, "per_journal_scores.jsonl"), per_journal)
