import json

def read_jsonl(path):
    """Read a JSONL file and return a list of dicts."""
    data = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            if line.strip():
                data.append(json.loads(line))
    return data


def write_json(path, obj):
    """Write a JSON file with pretty formatting."""
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, indent=2)


def write_jsonl(path, rows):
    """Write a list of dicts to JSONL."""
    with open(path, "w", encoding="utf-8") as f:
        for row in rows:
            f.write(json.dumps(row) + "\n")
